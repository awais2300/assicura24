<?php $this->load->view('front_app/common/header'); ?>
<style>
  select {
    font-family: 'FontAwesome', 'Second Font name'
  }

  .red-border {
    border: 1px solid red !important;
  }
</style>
<div style="height:470px;padding:90px;" class="container">
  <label style="color:#885ead;font-size:20px">OPEN YOUR EYES AND CHECKOUT HOW TO SAVE MONEY FOR YOUR INSURANCE CAR</label>
  <form role="form" method="post" id="insurance_form" enctype="multipart/form-data" style="margin-top:50px;" action="<?= base_url(); ?>Home/additional_info">
    <div class="box-body">
      <div class="form-group col-md-6">
        <label style="font-size:15px">Select car type<span style="color: #FF0000;">*</span></label>
        <select class="form-control select2 " name="car_type" id="car_type" data-placeholder="Choose Vehicle type" style="width: 100%;font-family: 'FontAwesome', 'Arial'">
          <option value="" style=" font-family: Arial, Helvetica, sans-serif;">Choose Car type </option>
          <option value="truck" style="font-family: 'FontAwesome', 'Arial'">&#xf0d1; &nbsp <p style="font-family: Arial, Helvetica, sans-serif"> Truck </p>
          </option>
          <option value="bus" style="font-family: 'FontAwesome', 'Arial'">&#xf207; &nbsp&nbsp Bus </option>
          <option value="car" style="font-family: 'FontAwesome', 'Arial'"> &#xf1b9; &nbsp Car </option>
          <option value="bike" style="font-family: 'FontAwesome', 'Arial'">&#xf21c; &nbsp Bike </option>

        </select>
      </div>
      <div class="clearfix"></div>
      <div class="form-group col-md-6">
        <label for="name">Number Plate<span style="color: #FF0000;">*</span></label>
        <input type="text" class="form-control" id="plate_no" maxlength="8" placeholder="Enter Plate No" name="plate_no">
      </div>

      <div class="clearfix"></div>
      <p style="color:red;font-size:14px;display:none;margin-left:25px;font-weight:600;font-family:Arial, Helvetica, sans-serif" id="plate_error">* Invalid Plate No</p>
      <p style="color:red;font-size:14px;display:none;margin-left:25px;font-weight:600;font-family:Arial, Helvetica, sans-serif" id="empty_error">* Fill in the required fields</p>
      <p style="color:red;font-size:14px;display:none;margin-left:25px;font-weight:600;font-family:Arial, Helvetica, sans-serif" id="plate_no_exist_error">* This plate number already exists.</p>

      <div class="box-footer col-md-6 " style="padding-top:10px">
        <button style="background-color:#885ead;font-family:Arial, Helvetica, sans-serif" type="button" id="submitbutton" class="btn btn-primary col-md-12">CHECK THE OFFER</button>
      </div>
    </div>

  </form>
</div>
<?php $this->load->view('front_app/common/footer'); ?>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script>
  $('#submitbutton').on('click', function() {
    //alert('button pressed');
    $('#submitbutton').attr('disabled', true);
    var validate = 0;
    var car_type = $('#car_type').val();
    var plate_no = $('#plate_no').val();

    if (car_type == '') {
      validate = 1;
      $('#car_type').addClass('red-border');
      $('#empty_error').show();
    }
    if (plate_no == '') {
      validate = 1;
      $('#plate_no').addClass('red-border');
      $('#empty_error').show();
    }
    if (!/[A-Za-z0-9]+$/.test(plate_no) && plate_no != '') {
      validate = 1;
      $('#plate_no').addClass('red-border');
      $('#plate_error').show();
    }
    if (plate_no.length < 6 || plate_no.length > 7) {
      validate = 1;
      $('#plate_no').addClass('red-border');
      $('#plate_error').show();
    }

    if (validate == 0) {
      $('#insurance_form')[0].submit();
    } else {
      $('#submitbutton').removeAttr('disabled');
    }

  });


  $('#plate_no').on('blur', function() {
    //alert('df');
    var plate_no = $('#plate_no').val();
    //alert(plate_no);
    $.ajax({
      url: '<?= base_url(); ?>Home/plate_no_exists',
      method: 'POST',
      data: {
        'plate_no': plate_no
      },
      success: function(data) {
        //alert(data);
        if (data == 1) {
          $('#plate_no_exist_error').show();
          $('#submitbutton').attr('disabled', true);
        } else {
          $('#plate_no_exist_error').hide();
          $('#submitbutton').removeAttr('disabled');
        }
      },
      error: function(data) {
        alert('failure');
      }
    });

  });

  let alreadyUser = document.getElementById('alreadyUser');
  alreadyUser.innerHTML = `<a> Already a user? <a href="<?= base_url(); ?>User_Login" style="color:darkred">Login</a></a>`;

  let btn = document.getElementById('submitbutton');
  btn.addEventListener("mouseover", function() {
    // carIcon = carIcon.parentElement;
    btn.style.backgroundColor = `rgb(120, 79, 143)`;
  });
  btn.addEventListener("mouseleave", function() {
    // carIcon = carIcon.parentElement;
    btn.style.backgroundColor = `rgb(136, 94, 173)`;
  });
</script>