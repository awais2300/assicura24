		<?php $this->load->view('admin/common/header'); ?>
		<style>
			/* Dropdown Button */
			.dropbtn {
				background-color: #885ead;
				color: white;
				padding: 16px;
				font-size: 16px;
				border: none;
			}

			/* The container <div> - needed to position the dropdown content */
			.dropdown {
				position: relative;
				display: inline-block;
			}

			/* Dropdown Content (Hidden by Default) */
			.dropdown-content {
				display: none;
				position: absolute;
				background-color: #f1f1f1;
				min-width: 160px;
				box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
				z-index: 1;
			}

			/* Links inside the dropdown */
			.dropdown-content a {
				color: black;
				padding: 10px 14px;
				text-decoration: none;
				display: block;
			}

			/* Change color of dropdown links on hover */
			.dropdown-content a:hover {
				background-color: #ddd;
			}

			/* Show the dropdown menu on hover */
			.dropdown:hover .dropdown-content {
				display: block;
			}

			/* Change the background color of the dropdown button when the dropdown content is shown */
			.dropdown:hover .dropbtn {
				background-color: #885ead;
				;
			}
		</style>
		<div class="container my-3">

			<label style="color:#885ead;font-size:30px">User Requests</label>


			<div id="table_div" style="padding:20px 80px 90px 80px">

				<table id="datatable" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Request No</th>
							<th>Isurance type</th>
							<th>Plate Number</th>
							<th>Status</th>
							<th>Date updated</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>
						<?php $count = 0;
						foreach ($request_data as $data) { ?>
							<tr>
								<td><?php $count++;
									echo $count; ?></td>
								<td><?= $data['request_no'] ?></td>
								<td><?= $data['type_of_contract']; ?></td>
								<td><?= $data['Plate_no']; ?></td>
								<?php if ($data['status'] == 'inactive') { ?>
									<td><a style="width:145px" href="" class="btn btn-danger"> <?= $data['status']; ?></a></td>
								<?php } else if ($data['status'] == 'Issued') { ?>
									<td><a style="width:145px" href="" class="btn btn-success"> <?= $data['status']; ?></a></td>
								<?php } else if ($data['status'] == 'To be managed') { ?>
									<td><a style="width:145px" href="" class="btn btn-info"> <?= $data['status']; ?></a></td>
								<?php } else if ($data['status'] == 'Ready to buy') { ?>
									<td><a style="width:145px" href="" class="btn btn-primary"> <?= $data['status']; ?></a></td>
								<?php } else { ?>
									<td><a style="width:145px" href="" class="btn btn-secondary"> <?= $data['status']; ?></a></td>
								<?php } ?>
								<td><?= date('M d,Y', strtotime($data['date_request'])); ?></td>

								<td>
									<div class="dropdown">
										<button class="dropbtn">Actions</button>
										<div class="dropdown-content">
											<a href="<?= base_url(); ?>request_detail/<?= $data['request_no']; ?>">Manage Request</a>
											<?php if ($data['status'] != 'inactive') { ?>
												<a href="<?= base_url(); ?>suspend_contract/<?= $data['request_no']; ?>">Suspend</a>
											<?php } ?>
											<?php if ($data['status'] != 'close') { ?>
												<a href="<?= base_url(); ?>close_contract/<?= $data['request_no']; ?>">Closed</a>
											<?php } ?>
											<?php if ($data['status'] != 'Contract replacement') { ?>
												<a href="<?= base_url(); ?>replace_contract/<?= $data['request_no']; ?>">Replaced</a>
											<?php } ?>
										</div>
									</div>
									<!--<a class="btn btn-default" style="background-color:#885ead;color:white;font-weight:600" href="<?= base_url(); ?>request_detail/<?= $data['request_no']; ?>" >View Request </a>-->
								</td>
							</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php $this->load->view('userpanel/common/footer'); ?>