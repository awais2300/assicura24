<?php $this->load->view('front_app/common/header'); ?>

<style>
  select {
    font-family: 'FontAwesome', 'Second Font name';
    font-family: Arial, Helvetica, sans-serif;
  }

  .red-border {
    border: 1px solid red !important;
  }

  #flip {
    margin-top: 15px;
  }

  #panel,
  #flip {

    padding: 5px 15px 5px 5px;
    text-align: left;
    background-color: #e9e7e7;
    border: solid 1px #c3c3c3;
  }

  #panel {
    padding: 35px;
    display: none;
    font-size: 16px;
    color: black
  }

  input[type="file"] {
    padding: 3px;
    display: block;
    border: 1px solid #ccc;
    width: 457px;
    border-radius: 4px;
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
    transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
  }
</style>
<div style="height:auto;padding:30px 100px 150px 100px;" class="container">
  <label style="color:#885ead;font-size:20px">IDENTIFICATION INFORMATION</label>
  <form role="form" method="post" id="insurance_form" enctype="multipart/form-data" style="margin-top:20px;" action="<?= base_url(); ?>Home/identification_process">
    <div class="box-body">
      <div class="form-group col-md-6">
        <label style="font-size:14px">Registeration Certificate<span style="color: #FF0000;">*</span></label>
        <input type="file" name="reg_cert[]" id="reg_cert" multiple="multiple">
        <label class="reg_cert" style="color:gray;font-size:14px">* Upload maximum 3 files</label>
      </div>
      <div class="clearfix"></div>
      <div class="form-group col-md-6">
        <label style="font-size:14px">Fiscal Code<span style="color: #FF0000;">*</span></label>
        <input type="file" name="fiscal_code[]" id="fiscal_code" multiple="multiple">
        <label class="fiscal_code" style="color:gray;font-size:14px">* Upload maximum 2 files</label>
      </div>
      <div class="clearfix"></div>
      <div class="form-group col-md-6">
        <label style="font-size:14px">ID<span style="color: #FF0000;">*</span></label>
        <input type="file" name="identification[]" id="Identification" multiple="multiple">
        <label class="fiscal_code" style="color:gray;font-size:14px">* Upload maximum 2 files</label>
      </div>
      <div class="clearfix"></div>
      <div class="form-group col-md-6">
        <label style="font-size:14px">Post Contract<span style="color: #FF0000;">*</span></label>
        <select class="form-control" name="post_contract" id="post_contract" data-placeholder="Choose Vehicle type">
          <option value="">Choose type </option>
          <option value="email"> Email (recommended) </option>
          <option value="printed">Printed </option>
        </select>
      </div>
      <input type="hidden" name="last_user_id" value="<?= $last_user_id ?>">
      <div class="form-group col-md-12">

        <div id="flip" style="background-color:#e9e7e7; color:black; font-weight:800;font-size:15px;">PRIVACY INFORMATION<i class="fa fa-plus" style="float:right;margin-top:8px;"></i></div>
        <div id="panel">
          <input type="checkbox" name="privacy_checkbox" id="privacy_checkbox">
          A privacy policy is a statement or a legal document that discloses some or all of the ways a party gathers, uses, discloses, and manages a customer or client's data.
        </div>
      </div>

      <div class="clearfix"></div>
      <p style="color:red;font-size:14px;display:none;margin-left:25px;font-weight:600;font-family:Arial, Helvetica, sans-serif" id="plate_error">* Invalid Plate No</p>
      <p style="color:red;font-size:14px;display:none;margin-left:25px;font-weight:600;font-family:Arial, Helvetica, sans-serif" id="privacy_error">* Please check privacy policy</p>
      <p style="color:red;font-size:14px;display:none;margin-left:25px;font-weight:600;font-family:Arial, Helvetica, sans-serif" id="empty_error">* Fill in the required fields</p>

      <div class="box-footer col-md-6 " style="padding-top:10px">
        <button style="background-color:#885ead;margin-left:240px;font-family:Arial, Helvetica, sans-serif" type="button" id="submitbutton" class="btn btn-primary col-md-12">PROCEED TO OFFER</button>
      </div>
    </div>

  </form>
</div>
<?php $this->load->view('front_app/common/footer'); ?>
<script>
  $('#submitbutton').on('click', function() {
    //alert('button pressed');
    $('#submitbutton').attr('disabled', true);
    var validate = 0;
    var postal_contract = $('#postal_contract').val();

    if ($("input[type=checkbox]").is(
        ":checked")) {
      $('#privacy_error').hide();
    } else {
      validate = 1;
      $('#privacy_error').show();
    }
    if (document.getElementById("reg_cert").files.length == 0) {
      validate = 1;
      //alert('2');

      $('#reg_cert').addClass('red-border');
    } else if (document.getElementById("reg_cert").files.length > 3) {
      //alert('3');
      validate = 1;
      $('#reg_cert').addClass('red-border');
      $('.reg_cert').css('color', 'red');
    }

    /* fiscal code */
    if (document.getElementById("fiscal_code").files.length == 0) {
      validate = 1;
      $('#fiscal_code').addClass('red-border');
    } else if (document.getElementById("fiscal_code").files.length > 2) {


      validate = 1;
      $('#fiscal_code').addClass('red-border');
    }
    /* ID */
    if (document.getElementById("Identification").files.length == 0) {
      validate = 1;
      $('#Identification').addClass('red-border');
    } else if (document.getElementById("Identification").files.length > 2) {
      validate = 1;
      $('#Identification').addClass('red-border');
      $('.').css('color', 'red');

    }

    if ($(":selected").val() === "") {
      validate = 1;
      $('.form-control').addClass('red-border');
      $('#empty_error').show();
    }

    if (validate == 0) {
      $('#insurance_form')[0].submit();
    } else {
      $('#submitbutton').removeAttr('disabled');
    }

  });
</script>

<script>
  $(document).ready(function() {
    $("#flip").click(function() {
      $("#panel").slideToggle();
    });
  });

  let btn = document.getElementById('submitbutton');
  btn.addEventListener("mouseover", function() {
    btn.style.backgroundColor = `rgb(120, 79, 143)`;
  });
  btn.addEventListener("mouseleave", function() {
    btn.style.backgroundColor = `rgb(136, 94, 173)`;
  });
</script>

<script src="jquery-1.10.2.min.js"></script>