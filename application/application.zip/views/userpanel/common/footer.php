<footer id="htc__footer">
    <!-- Start Footer Widget -->
    <!-- <div class="footer__container bg__cat--1">
                <div class="container">
                    <div class="row">
                        <!-- Start Single Footer Widget
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="footer">
                                <h2 class="title__line--2">ABOUT US</h2>
                                <div class="ft__details">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim</p>
                                    <div class="ft__social__link">
                                        <ul class="social__link">
                                            <li><a href="#"><i class="icon-social-twitter icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-instagram icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-facebook icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-google icons"></i></a></li>

                                            <li><a href="#"><i class="icon-social-linkedin icons"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                   
                     
                        <!-- End Single Footer Widget
                    </div>
                </div>
            </div>-->
    <!-- End Footer Widget -->
    <!-- Start Copyright Area -->
    <div class="fixed-bottom htc__copyright bg__cat--5" style="text-align:center">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="copyright__inner col-xs-12" style="margin-left:0px">
                    <p class="col-xs-12" style="font-family: Arial;">Copyright© <a style="color:white;font-weight:1000;font-family: Arial;" href="">Artabz technologies Pvt. Ltd.</a> 2020. All right reserved.</p>
                        <!--<a href="#"><img src="<?php //echo base_url();
                                                    ?>/assets2/images/others/shape/paypol.png" alt="payment images"></a>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Copyright Area -->
</footer>
<!-- End Footer Style -->
</div>
<!-- Body main wrapper end -->

<!-- Placed js at the end of the document so the pages load faster -->

<!-- jquery latest version -->

<!-- Bootstrap framework js -->
<!--<script src="<?php echo base_url(); ?>assets2/js/vendor/jquery-3.2.1.min.js"></script>-->

<!-- All js plugins included in this file. -->
<script src="<?php echo base_url(); ?>assets2/js/plugins.js"></script>
<script src="<?php echo base_url(); ?>assets2/js/slick.min.js"></script>
<script src="<?php echo base_url(); ?>assets2/js/owl.carousel.min.js"></script>
<!-- Waypoints.min.js. -->
<!-- <script src="<?php echo base_url(); ?>assets2/js/waypoints.min.js"></script>-->
<!-- Main js file that contents all jQuery plugins activation. -->
<script src="<?php echo base_url(); ?>assets2/js/main.js"></script>

<script src="<?php echo base_url(); ?>assets/dist/js/app.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/swal/swal.all.min.js"></script>
<?php if ($this->session->flashdata('success')) : ?>

    <script>
        Swal.fire(
            '<?php echo $this->session->flashdata('success'); ?>',
            '',
            'success'
        );
    </script>
<?php endif; ?>

<?php if ($this->session->flashdata('failure')) : ?>
    <script src="<?php echo base_url(); ?>assets/plugins/swal/swal.all.min.js"></script>
    <script>
        Swal.fire(
            '<?php echo $this->session->flashdata('failure'); ?>',
            '',
            'error'
        );
    </script>
<?php endif; ?>
</body>

<!--<script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>-->

<!-- AdminLTE App -->



</html>