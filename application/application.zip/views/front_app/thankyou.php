<?php $this->load->view('front_app/common/header'); ?>
<style>
  select {
    font-family: 'FontAwesome', 'Second Font name'
  }

  .red-border {
    border: 1px solid red !important;
  }
</style>
<div style="height:470px;padding:90px;" class="container">
  <?php if ($option == 'no') { ?>
    <label style="color:#885ead;font-size:20px;line-height:35px;">THANKYOU FOR YOUR REQUEST TO QUOTE OFFER, VERIFICATION EMAIL HAS BEEN
      SENT TO YOU, WE WILL GET BACK TO YOU SOON WITH AN AMAZING OFFER.</label>
    <div class="linktohome" style="text-align:center">
      <a href="<?php echo base_url(); ?>Home"> Back to Main Page </a>
    </div>
  <?php } else { ?>
    <label style="color:#885ead;font-size:20px;line-height:35px;margin-left:70px">YOUR REQUEST HAS BEEN SUCCESSFULLY SENT TO ADMINISTRATOR, WE WILL GET BACK TO YOU SOON.</label>
    <div class="linktohome" style="text-align:center">
      <a href="<?php echo base_url(); ?>User_Login"> Back to Main Page </a>
    </div>
  <?php } ?>
</div>
<?php $this->load->view('front_app/common/footer'); ?>